package com.cs3300g1.backend.repositories;

import com.cs3300g1.backend.models.Food;
import com.cs3300g1.backend.models.FoodType;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * This interface represents the repository for the collection foods in MongoDB. This repository
 * will be used to perform CRUD (Create, Read, Update, Delete) operations on the foods collection.
 */
@Repository
public interface FoodRepository extends MongoRepository<Food, String> {
  /**
   * Finds a list of Food items by their name in the database.
   *
   * @param name the name of the food item to search for in the database.
   * @return a list of Food items that match the given name.
   */
  List<Food> findByName(String name);

  /**
   * Finds a list of Food items by their type in the database.
   *
   * @param type the type of food item to search for in the database (e.g., ITEM, MEAL).
   * @return a list of Food items that match the given type.
   */
  List<Food> findByType(FoodType type);
}
